package com.example.loginauthapi.dto;

public record ResponseDTO (String name, String token) { }
